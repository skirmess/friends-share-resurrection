
FriendsShare Resurrection is an AddOn that lets you keep the same
friends list across characters, on a per server basis.

If you add or remove someone from your friends list and relog to an
alt, that person will be added/removed from the alts friends list as
well. Also, any entries on that alts list which isn't in the global
list, will be added to the other characters whenever you log them in.

Basically, you never have to manually rebuild your friends list when
creating alts, or worry about keeping them current on all your alts.

This all works seamlessly without any user intervention.

As an additional plus, if Blizzard decides to clean out the friends
list, this Addon will automatically rebuild your friend list. This
clean out happens sometimes during server maintenance. :-)

Known issue: If you try to add someone to your friends list and the
server won't let you do it (say, if a Horde char tries to add an
Alliance char to the list, or you misspell the name), that entry will
still end up on the global list, and so you'll get the error message
you got trying to add it, every time you log on. So, if this happens
to you, do '/friendsshare rebuild' and the global list will be rebuilt
from that char's list, and all invalid entries discarded.

This Addon was written originally by Oystein, all credit belongs to
him.


*** Changelog

Version 4
There was a problem when you target a player and add him to the
  friendlist.


Version 3
Way better event handling (resolves the race condition during
  login which could crash the WoW client).
  Inspired by "Friend & Ignore Share v1.3, thanks Vimrasha.
Fixed the "gfind" Lua 5.1 syntax change problem.


Version 2 (based on 1.1 from Oystein)

Catch the case where the friend list is not yet loaded from the
  server. Try again later if the list was not ready the first time.
Mention which chars were added or removed from the friend list.
Delete first, then add new friends.
Lua 5.1 syntax change (had to use pairs())
added suffix FriendsShare_ to global variables
removed myAddOns code
